# opencv-car-number-plate-detection-
this  project  is  made  using python  and  opencv  . i  haven't  used  anything  machine learning  or  rendering  stuff  to  detect  number  plate . It  is  based  on  contour in  opencv  . it's  dosent  give  you  numbers directly  it's  just  highlights (gives  you  the coordinate )  the  rectangular area  of  number  plate  in  image    
